def chatbot():
    print("Chatbot: Hello! I am a simple chatbot.")
    print("Chatbot: Type 'bye' to exit.")

    while True:
        user = input("You: ").lower()

        if user == "hello" or user == "hi":
            print("Chatbot: Hello! How are you?")

        elif "how are you" in user:
            print("Chatbot: I am fine. Thank you!")

        elif "your name" in user:
            print("Chatbot: My name is Python Chatbot.")

        elif "what can you do" in user:
            print("Chatbot: I can answer simple questions and chat with you.")

        elif "thank you" in user or "thanks" in user:
            print("Chatbot: You're welcome!")

        elif user == "bye":
            print("Chatbot: Goodbye! Have a nice day.")
            break

        else:
            print("Chatbot: Sorry, I don't understand that.")

chatbot()