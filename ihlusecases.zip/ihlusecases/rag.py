from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Knowledge base
documents = [
    "Python is a programming language used for web development, AI, data science and automation.",
    "Java is an object-oriented programming language used for backend development and Android applications.",
    "RAG stands for Retrieval Augmented Generation. It retrieves relevant information from documents before generating an answer.",
    "Machine Learning is a branch of AI that allows computers to learn from data.",
    "Artificial Intelligence is the ability of computers to perform tasks that normally require human intelligence."
]

# Create TF-IDF model
vectorizer = TfidfVectorizer()
document_vectors = vectorizer.fit_transform(documents)


# RAG function
def chatbot(question):

    # Convert question into vector
    question_vector = vectorizer.transform([question])

    # Find similarity
    similarity = cosine_similarity(
        question_vector,
        document_vectors
    )

    # Find most relevant document
    best_index = similarity.argmax()

    best_score = similarity[0][best_index]

    # If nothing is relevant
    if best_score < 0.1:
        return "Sorry, I don't know the answer."

    # Retrieved information
    answer = documents[best_index]

    return answer


# Chatbot
print("RAG Chatbot")
print("Type 'bye' to exit.\n")

while True:

    question = input("You: ")

    if question.lower() == "bye":
        print("Bot: Goodbye!")
        break

    answer = chatbot(question)

    print("Bot:", answer)